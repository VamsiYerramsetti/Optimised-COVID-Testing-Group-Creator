# CorolaFinder

First do:
```
cmake .
```
Then:
```
make
./corolafinder
```
